# ShopWise AI — Judge preparation

## 4-minute demonstration
0:00–0:30: Explain the decision overload problem and that the app is a decision assistant, not a store.
0:30–1:30: Enter a headphones request under $100 in sample mode. Show intent extraction, catalogue source, scoring and risk flags.
1:30–2:15: Compare three products. Discuss affordability, rating, relevance, availability, completeness and value.
2:15–3:00: Optimize a headphones-and-bag basket for $100; explain bounded exhaustive search of candidate combinations.
3:00–3:40: Add to simulated cart, save a decision, download PDF.
3:40–4:00: Show actual agent activity logs and explain API/Gemini fallback.

## Architecture
Streamlit UI -> optional Gemini structured intent (fallback: deterministic parser) -> fixed task plan -> DummyJSON product search (or explicitly offline sample) -> normalization -> weighted heuristic score + risk flags -> recommendation / bounded combination optimization -> SQLite persistence and PDF report. Gemini can also explain provided results but cannot create catalogue records.

## Scoring
Weighted score = 20% affordability + 20% rating + 15% availability + 25% keyword relevance + 5% completeness + 15% value. All component scores range from 0 to 1. Over-budget products receive a score penalty. This is not trained ML, and weights are design choices, not scientifically validated.

## Likely questions and defensible answers
1. **What is the problem?** Too many confusing choices and insufficient transparent comparison.
2. **What is the solution?** A guided product decision workflow with auditable criteria.
3. **What makes it agent-like?** It interprets an intent, follows a task plan, calls tools, evaluates and acts by saving/carting. Planning is currently predefined.
4. **Is it autonomous?** No, it is a bounded, user-triggered agent workflow.
5. **How is it different from a store?** It explains trade-offs and supports cross-category budget optimization; it does not sell anything.
6. **What does Gemini do?** Optional structured intent extraction and grounded natural-language explanations.
7. **What happens without Gemini?** A deterministic parser and explanation fallback operate locally.
8. **Is there a trained ML model?** No. Scoring is transparent, heuristic Python logic.
9. **Which external API is used?** DummyJSON public demonstration catalogue, not a live merchant feed.
10. **Are prices real?** They are demo catalogue prices and must not be treated as current retailer offers.
11. **How are risks detected?** Missing fields, low ratings, unavailable stock and large discounts trigger heuristic warnings.
12. **Can you detect fraud?** No; discounts are flagged for verification, not labelled fraudulent.
13. **How is the score calculated?** Six weighted components and a budget penalty.
14. **Why those weights?** Illustrative defaults, adjustable in future; no claim of empirical calibration.
15. **How is budget optimization done?** Exhaustive search over a bounded shortlist, filtering unavailable items and over-budget combinations.
16. **Is optimization globally optimal?** Only within the shortlisted candidates, not the entire market.
17. **What if nothing fits?** The app reports no feasible combination and suggests adjusting constraints.
18. **Why SQLite?** Lightweight local persistence without a server.
19. **Which tables are used?** Sessions, search history, decisions, cart items, and agent activity.
20. **What does the activity page show?** Actual application logs from executed workflow steps.
21. **What if the product API fails?** The app reports the failure and lets the user explicitly enable offline sample mode.
22. **Is fallback data silently mixed with API data?** No, each search is labelled by its source.
23. **Does the app support INR?** It recognizes INR but blocks INR budgets because the demo catalogue uses USD and conversion is not implemented.
24. **Can users buy products?** No; cart and actions are simulations, with no payments.
25. **How are secrets protected?** API keys are stored in Streamlit secrets or local configuration excluded from version control.
26. **What was tested?** Unit tests for parsing, scoring, risk flags, optimization and sample catalogue; live integrations require separate end-to-end testing.
27. **What are the limitations?** Demo data, fixed planning, no merchant verification, no multi-user accounts, no live currency conversion.
28. **What would you improve?** Licensed retailer feeds, price history, user-adjustable weights, grounded reviews, multi-user auth and evaluated recommendation quality.
