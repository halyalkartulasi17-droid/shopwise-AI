import sqlite3, json
from pathlib import Path
DB=Path(__file__).resolve().parent.parent/'shopwise.db'
def connect():
    conn=sqlite3.connect(DB)
    conn.row_factory=sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    return conn

def init():
    with connect() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS shopping_sessions(id INTEGER PRIMARY KEY, query TEXT NOT NULL, source TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS search_history(id INTEGER PRIMARY KEY, session_id INTEGER REFERENCES shopping_sessions(id), product_count INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS saved_decisions(id INTEGER PRIMARY KEY, session_id INTEGER REFERENCES shopping_sessions(id), summary TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS cart_items(id TEXT PRIMARY KEY, title TEXT NOT NULL, price REAL NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>0), source TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS agent_activity(id INTEGER PRIMARY KEY, session_id INTEGER REFERENCES shopping_sessions(id), stage TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);''')

def log(session,stage,detail):
    with connect() as c: c.execute('INSERT INTO agent_activity(session_id,stage,detail) VALUES(?,?,?)',(session,stage,detail))
def start(query,source,count):
    with connect() as c:
        cur=c.execute('INSERT INTO shopping_sessions(query,source) VALUES(?,?)',(query,source)); sid=cur.lastrowid
        c.execute('INSERT INTO search_history(session_id,product_count) VALUES(?,?)',(sid,count))
        return sid
def add(item):
    with connect() as c:
        c.execute('INSERT INTO cart_items(id,title,price,quantity,source) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET quantity=quantity+1',(item.source+'::'+item.id,item.title,item.price,1,item.source))
def cart():
    with connect() as c: return [dict(x) for x in c.execute('SELECT * FROM cart_items ORDER BY title')]
def quantity(id,n):
    with connect() as c:
        if n <= 0: c.execute('DELETE FROM cart_items WHERE id=?',(id,))
        else: c.execute('UPDATE cart_items SET quantity=? WHERE id=?',(n,id))
def save(session,summary,payload):
    with connect() as c: c.execute('INSERT INTO saved_decisions(session_id,summary,payload) VALUES(?,?,?)',(session,summary,json.dumps(payload)))
def decisions():
    with connect() as c: return [dict(x) for x in c.execute('SELECT * FROM saved_decisions ORDER BY id DESC')]
def activities():
    with connect() as c: return [dict(x) for x in c.execute('SELECT * FROM agent_activity ORDER BY id DESC LIMIT 150')]
def stats():
    with connect() as c:
        return {'searches':c.execute('SELECT COUNT(*) FROM search_history').fetchone()[0], 'evaluated':c.execute('SELECT COALESCE(SUM(product_count),0) FROM search_history').fetchone()[0], 'decisions':c.execute('SELECT COUNT(*) FROM saved_decisions').fetchone()[0]}
