import json
from pathlib import Path
import requests
from .core import normalize
BASE='https://dummyjson.com/products'
SAMPLE=Path(__file__).resolve().parent.parent/'data'/'sample_products.json'

def search_products(query, offline=False, limit=30):
    if offline:
        rows=json.loads(SAMPLE.read_text(encoding='utf-8'))
        terms=query.lower().split()
        matches=[x for x in rows if any(t in (x['title']+' '+x['category']+' '+x.get('description','')).lower() for t in terms)]
        return [normalize({**x,'source':'SAMPLE / OFFLINE'}) for x in matches], 'SAMPLE / OFFLINE'
    response=requests.get(BASE+'/search',params={'q':query,'limit':min(100,max(1,int(limit)))},timeout=8)
    response.raise_for_status()
    data=response.json()
    if not isinstance(data,dict) or not isinstance(data.get('products'),list):
        raise ValueError('Product provider returned an unexpected response.')
    rows=data['products']
    normalized=[]
    for x in rows:
        try:
            item=normalize({**x,'source':'DummyJSON public demo API'})
            if item.price > 0: normalized.append(item)
        except (TypeError,ValueError,KeyError):
            continue
    return normalized, 'DummyJSON public demo API'
