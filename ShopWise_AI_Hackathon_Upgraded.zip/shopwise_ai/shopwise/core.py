import re
from dataclasses import dataclass, asdict
from itertools import product as cartesian

@dataclass
class Item:
    id: str
    title: str
    category: str
    price: float
    rating: float | None
    brand: str
    description: str
    stock: int
    source: str
    thumbnail: str = ""
    discount: float = 0.0

def parse_intent(query):
    """Deterministic, offline intent extraction. Currency is not converted."""
    if not isinstance(query, str) or not query.strip():
        raise ValueError('Describe the products you want to buy.')
    q = query.lower()
    budget_match = re.search(r'(?:under|below|within|budget(?: of| is)?|maximum(?: of)?|up to|less than)\s*(?:₹|\$|rs\.?\s*|usd\s*)?\s*([\d,]+(?:\.\d{1,2})?)', q)
    budget = float(budget_match.group(1).replace(',', '')) if budget_match else None
    if budget is not None and (budget <= 0 or budget > 1_000_000_000):
        raise ValueError('Enter a valid positive budget.')
    aliases = {
        'headphones': ('headphones', 'headphone', 'earbuds', 'earphones', 'headset'),
        'laptops': ('laptops', 'laptop', 'notebook'),
        'smartphones': ('smartphones', 'smartphone', 'mobile phone', 'phone'),
        'watches': ('watches', 'watch', 'smartwatch'),
        'shoes': ('shoes', 'shoe', 'sneakers'),
        'tablets': ('tablets', 'tablet'),
        'bags': ('bags', 'bag', 'backpack', 'backpacks'),
        'beauty': ('beauty', 'skincare', 'makeup'),
        'furniture': ('furniture', 'chair', 'desk'),
        'groceries': ('groceries', 'grocery', 'food'),
    }
    found = [canonical for canonical, words in aliases.items() if any(re.search(r'(?<![a-z])'+re.escape(w)+r'(?![a-z])', q) for w in words)]
    if not found:
        cleaned = re.sub(r'\b(?:i|want|need|buy|find|me|a|an|for|with|and|the|best|under|below|within|budget|maximum|of|is|my|please|up|to)\b', ' ', q)
        cleaned = re.sub(r'[\d,.$₹]+', ' ', cleaned)
        found = [cleaned.strip()[:60] or 'products']
    currency = 'INR' if '₹' in query or re.search(r'\brs\.?\b', q) else ('USD' if '$' in query or 'usd' in q else None)
    return {'query':query.strip(), 'categories':found, 'budget':budget, 'currency':currency,
            'priorities':[w for w in ('travel','college','classes','gaming','music','programming','battery','camera','noise cancellation') if w in q]}

def normalize(raw):
    if not isinstance(raw, dict): raise ValueError('Product record must be an object')
    return Item(str(raw.get('id','')), str(raw.get('title','Untitled')), str(raw.get('category','other')),
        float(raw.get('price') or 0), float(raw['rating']) if raw.get('rating') is not None else None,
        str(raw.get('brand') or ''), str(raw.get('description') or ''), int(raw.get('stock') or 0),
        str(raw.get('source') or 'unknown'), str(raw.get('thumbnail') or ''), float(raw.get('discountPercentage') or 0))

def risks(item):
    flags=[]
    if item.price <= 0: flags.append('Invalid or missing price')
    if item.rating is not None and item.rating < 3.5: flags.append('Low rating')
    if item.stock <= 0: flags.append('Out of stock')
    if not item.brand: flags.append('Missing brand')
    if not item.description: flags.append('Missing description')
    if item.discount >= 60: flags.append('Large discount: verify original price')
    if item.rating is None: flags.append('Rating unavailable')
    return flags

def score(item, budget=None, keywords=None):
    if item.price <= 0: return 0.0, {}
    affordability = (max(0, 1-item.price/budget) if budget and budget > 0 else 0.5)
    rating = min(1.0, max(0.0, item.rating/5)) if item.rating is not None else 0.35
    available = 1.0 if item.stock > 0 else 0.0
    words = [w for w in re.findall(r'[a-z]{4,}', ' '.join(keywords or []).lower()) if w not in {'want','need','with','under','below','maximum','budget','best','please'}]
    content = (item.title+' '+item.description+' '+item.category).lower()
    relevance = sum(w in content for w in words)/len(words) if words else 0.5
    completeness = sum(bool(x) for x in [item.title,item.brand,item.description,item.rating is not None])/4
    value = (rating*0.65 + affordability*0.35)
    parts={'Affordability':affordability,'Rating':rating,'Availability':available,'Relevance':relevance,'Completeness':completeness,'Value':value}
    weights={'Affordability':.20,'Rating':.20,'Availability':.15,'Relevance':.25,'Completeness':.05,'Value':.15}
    total=sum(parts[k]*weights[k] for k in weights)*100
    if budget is not None and item.price > budget: total *= .35
    return round(total,1), {k:round(v*100,1) for k,v in parts.items()}

def optimize(groups, budget):
    if budget is None or budget <= 0: return None
    if len(groups) > 5: raise ValueError('Select at most five categories per optimization.')
    choices=[]
    for group in groups:
        available=[x for x in group if x.stock > 0 and x.price > 0 and x.price <= budget]
        if not available: return None
        # Limit the Cartesian search to at most 8**5 combinations.
        available.sort(key=lambda x:score(x, budget, [x.category])[0], reverse=True)
        choices.append(available[:8])
    best=None
    for combination in cartesian(*choices):
        total=sum(i.price for i in combination)
        if total > budget: continue
        quality=sum(score(i, budget, [i.category])[0] for i in combination)
        if best is None or quality > best['quality']:
            best={'items':list(combination),'total':round(total,2),'remaining':round(budget-total,2),'quality':quality}
    return best
