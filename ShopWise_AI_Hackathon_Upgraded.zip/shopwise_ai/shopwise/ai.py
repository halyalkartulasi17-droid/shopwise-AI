import requests

def explain(query, products, api_key):
    if not api_key:
        return 'Rule-based explanation (Gemini not configured): the top product is selected using weighted affordability, rating, availability, relevance, completeness and value. Verify all specifications with the seller before purchasing.', 'RULE-BASED FALLBACK'
    context='\n'.join(f'{p["title"]}: price {p["price"]}, score {p["score"]}, flags {p["risks"]}' for p in products[:6])
    prompt=f'Explain the recommendation for user request: {query}. Only use these verified catalogue records; do not add specifications, prices or claims. State tradeoffs and uncertainty.\n{context}'
    try:
        r=requests.post('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',params={'key':api_key},json={'contents':[{'parts':[{'text':prompt}]}]},timeout=15)
        r.raise_for_status()
        return r.json()['candidates'][0]['content']['parts'][0]['text'], 'GEMINI'
    except (requests.RequestException,KeyError,IndexError,ValueError) as e:
        return f'Gemini unavailable ({type(e).__name__}). Using deterministic product ranking; compare scores and risk flags below.', 'RULE-BASED FALLBACK'


def understand_intent(query, api_key=''):
    """Optional Gemini intent interpretation. A validated offline parse is always available."""
    from .core import parse_intent
    fallback=parse_intent(query)
    if not api_key:
        return fallback, 'DETERMINISTIC FALLBACK'
    import json
    prompt=("Extract shopping requirements from the user's message. Return ONLY a JSON object "
            "with categories (array of shopping category strings), budget (positive number or null), "
            "currency (USD, INR or null), priorities (array of strings). "
            "Do not invent a budget, currency or products. Message: "+query[:2000])
    try:
        response=requests.post('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
            params={'key':api_key}, json={'contents':[{'parts':[{'text':prompt}]}],
            'generationConfig':{'responseMimeType':'application/json','temperature':0}},timeout=15)
        response.raise_for_status()
        raw=response.json()['candidates'][0]['content']['parts'][0]['text']
        data=json.loads(raw)
        if not isinstance(data,dict): raise ValueError('Unexpected Gemini intent shape')
        categories=data.get('categories')
        if not isinstance(categories,list) or not categories or not all(isinstance(x,str) and 0<len(x)<65 for x in categories):
            raise ValueError('Invalid categories')
        budget=data.get('budget')
        if budget is not None and (isinstance(budget,bool) or not isinstance(budget,(int,float)) or not 0<budget<=1_000_000_000):
            raise ValueError('Invalid budget')
        # Preserve explicit monetary constraints from the user's message.
        if fallback['budget'] is not None: budget=fallback['budget']
        currency=fallback['currency'] or (data.get('currency') if data.get('currency') in ('USD','INR') else None)
        priorities=data.get('priorities',[])
        if not isinstance(priorities,list): priorities=[]
        return {'query':query.strip(),'categories':categories[:5], 'budget':budget, 'currency':currency,
                'priorities':[x for x in priorities if isinstance(x,str)][:10]}, 'GEMINI STRUCTURED INTENT'
    except (requests.RequestException, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError):
        return fallback, 'DETERMINISTIC FALLBACK (Gemini unavailable or invalid)'
