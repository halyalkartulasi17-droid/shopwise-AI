# ShopWise AI — Explainable Shopping Decision Agent

A local Streamlit hackathon MVP. **No real checkout or payments.** DummyJSON is a public *demo catalogue*, not a live retailer. Offline records are invented sample products, clearly labelled.

## Windows VS Code PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

If activation is blocked, use `.\.venv\Scripts\python.exe -m pip install -r requirements.txt` and `.\.venv\Scripts\python.exe -m streamlit run app.py`.

## Optional Gemini
Copy `.streamlit/secrets.toml.example` to `.streamlit/secrets.toml` and set `GEMINI_API_KEY`. Gemini 2.5 Flash is used only to explain grounded results; it never supplies catalogue values. Missing/failing Gemini falls back to a deterministic explanation.

## Data and API
`https://dummyjson.com/products/search?q=<term>` is queried via Requests with an 8-second timeout. It provides a demonstration catalogue in USD, not live retail offers. The offline mode loads `data/sample_products.json` and is never described as live. API failures are displayed rather than silently masked.

## Scoring and optimizer
Weighted score = affordability 20% + rating 20% + availability 15% + keyword relevance 25% + completeness 5% + value 15%. Values are normalized to [0,1]. Over-budget products are penalized. This is a **heuristic**, not a trained ML model. For multi-category baskets, the optimizer enumerates up to 25 available options per category and selects the feasible combination with highest sum of scores. This is a bounded exact search over the shortlist, not globally optimal over an unbounded catalogue.

## SQLite tables
- `shopping_sessions`: id PK, query, source, created_at.
- `search_history`: id PK, session_id FK, product_count, created_at.
- `saved_decisions`: id PK, session_id FK, summary, payload JSON, created_at.
- `cart_items`: id PK, title, price, quantity, source.
- `agent_activity`: id PK, session_id FK, stage, detail, created_at.
All writes use parameterized SQL. The SQLite database is created on first run.

## Test
```powershell
python -m pytest -q
python -m compileall -q app.py shopwise
```

## 3–5 minute demo
1. Open Dashboard: initial metrics are zero.
2. In AI Shopping Assistant, enable sample mode and enter `I need wireless headphones for online classes and travelling under 100`.
3. Run agent. Show extracted budget, source label, scored catalogue, risk flags, and score breakdown.
4. Compare three headphones; note the out-of-stock sample warning.
5. Run Budget Optimizer with `headphones, bags` and budget 100.
6. Add an item to the simulated cart, update quantity.
7. Generate explanation, save a decision and download PDF in Decision Reports.
8. Open Agent Activity to show actual logged stages.

## Limitations
- Intent extraction is a simple deterministic parser; Gemini does not yet perform structured intent extraction or dynamic tool planning.
- Product search is from DummyJSON, not real shopping merchant listings.
- Product availability is demo data, not guaranteed retailer stock.
- No currency conversion; use catalogue USD values.
- Optimization searches only the returned shortlist and may not find the global optimum.
- Ratings and discounts are catalogue fields, not independently verified.
- No authentication or multi-user isolation. Local demo only.

## Upgrade notes (November 2026)
- Optional Gemini structured JSON intent extraction is implemented with strict validation and deterministic fallback. It is **not** a free-running autonomous planner: the tool sequence is a transparent predefined workflow.
- Offline category matching no longer silently returns unrelated catalogue items when no match exists.
- Supports common category synonyms, plural product names, multi-category extraction, currency detection, and rejects INR budgets rather than comparing rupees to USD prices.
- Product API response validation and invalid-product filtering improved.
- Optimization is bounded to 5 categories and 8 top-ranked products per category (maximum 32,768 combinations). Results are optimal **within the shortlisted candidates only**.
- Cart item identifiers include data source to avoid cross-provider collisions.
- Activity logs show the intent extraction method, normalization, scoring and decisions. Generated explanations are explicitly marked Gemini or fallback.
- Expanded automated test suite. Test results depend on the environment; run the commands above on your computer.

### Important operational limits
This is a single-user local demonstration. Product prices are USD-denominated **demo catalogue figures**, not merchant offers. No INR-to-USD conversion is performed. Gemini and external catalogue calls require network access; Gemini requires your own API key. No actual purchases are possible. Do not describe this as a production-ready shopping platform, a trained product-prediction ML model, or an autonomous agent with unconstrained dynamic planning.

### Live demo checklist
1. Launch in offline sample mode; enter `I need wireless headphones for online classes and travelling under $100`.
2. Confirm intent, plan, score, risk flags, product comparison and cart work.
3. Enter `headphones, bags` in Budget Optimizer with budget `100` and inspect remaining budget.
4. Save the decision and download its PDF report; reload the application to confirm SQLite persistence.
5. Inspect Agent Activity to verify actual execution logs.
6. Optional: configure Gemini and demonstrate structured extraction/explanation. If Gemini is unavailable, clearly demonstrate fallback.
7. Optional: switch off offline mode and test the DummyJSON demo catalogue. Do not claim this shows live retail stock.
