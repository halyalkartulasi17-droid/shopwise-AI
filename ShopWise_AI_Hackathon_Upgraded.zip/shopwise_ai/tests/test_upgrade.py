import pytest
from shopwise.core import parse_intent, normalize, risks, optimize
from shopwise.ai import understand_intent
from shopwise.provider import search_products

def test_plural_and_multiple_categories():
    intent=parse_intent('Headphones and backpacks for college under $120')
    assert intent['categories']==['headphones','bags']
    assert intent['budget']==120
    assert intent['currency']=='USD'

def test_empty_input_rejected():
    with pytest.raises(ValueError): parse_intent('   ')

def test_inr_detection():
    assert parse_intent('laptop under ₹70,000')['currency']=='INR'

def test_gemini_fallback_without_key():
    result, mode=understand_intent('wireless headphones under 100')
    assert result['budget']==100 and 'FALLBACK' in mode

def test_offline_catalogue_provenance():
    items,source=search_products('headphones',offline=True)
    assert items and all(x.source==source for x in items)

def test_optimizer_budget_and_stock():
    headphones,_=search_products('headphones',offline=True)
    bags,_=search_products('bags',offline=True)
    answer=optimize([headphones,bags],100)
    assert answer is not None
    assert answer['total']<=100
    assert all(x.stock>0 for x in answer['items'])

def test_optimizer_too_many_categories():
    with pytest.raises(ValueError): optimize([[]]*6,100)

def test_bad_rating_clamped():
    from shopwise.core import score
    item=normalize({'id':'x','title':'Test','price':10,'rating':999,'stock':1})
    _,breakdown=score(item,100)
    assert breakdown['Rating']==100

def test_invalid_price_flag():
    item=normalize({'id':'x','title':'Test','price':0,'stock':1})
    assert 'Invalid or missing price' in risks(item)
