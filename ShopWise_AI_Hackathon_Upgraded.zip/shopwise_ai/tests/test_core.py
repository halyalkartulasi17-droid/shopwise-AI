from shopwise.core import Item,parse_intent,score,risks,optimize

def make(id,price,stock=2):return Item(id,id,'headphones',price,4.5,'Brand','Good wireless headphones',stock,'sample')
def test_intent():assert parse_intent('headphones under 100')['budget']==100
def test_score():assert 0<=score(make('a',50),100,['headphones'])[0]<=100
def test_risk():assert 'Out of stock' in risks(make('a',50,0))
def test_optimize():
    r=optimize([[make('a',50)],[make('b',20)]],100)
    assert r['total']==70 and r['remaining']==30
def test_no_solution():assert optimize([[make('a',80)],[make('b',80)]],100) is None
