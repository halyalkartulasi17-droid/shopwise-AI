import json
from dataclasses import asdict
from io import BytesIO
import pandas as pd
import plotly.express as px
import streamlit as st
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from shopwise import db
from shopwise.core import parse_intent,score,risks,optimize
from shopwise.provider import search_products
from shopwise.ai import explain, understand_intent

st.set_page_config(page_title='ShopWise AI',page_icon='🛍️',layout='wide')
st.markdown('''<style>.stApp{background:#f7f8fd;color:#14213d}h1,h2,h3{color:#17204a!important}.stButton>button[kind=primary]{background:#5546cc;border:0}.block-container{padding-top:2rem}</style>''',unsafe_allow_html=True)
db.init()
for key,default in [('items',[]),('session',None),('intent',{}),('ranked',[]),('mode','SAMPLE / OFFLINE'),('explanation','')]:
    if key not in st.session_state: st.session_state[key]=default

def rows(items):
    return [{'id':x.id,'Product':x.title,'Category':x.category,'Price':x.price,'Rating':x.rating,'Stock':x.stock,'Brand':x.brand,'Score':score(x,st.session_state.intent.get('budget'),[st.session_state.intent.get('query','')])[0],'Warnings':', '.join(risks(x)) or 'None','Source':x.source} for x in items]

def pdf_report(title,lines):
    buffer=BytesIO(); doc=SimpleDocTemplate(buffer); styles=getSampleStyleSheet(); story=[Paragraph(title,styles['Title']),Spacer(1,12)]
    from xml.sax.saxutils import escape
    for line in lines: story.append(Paragraph(escape(str(line)),styles['BodyText'])); story.append(Spacer(1,8))
    doc.build(story);return buffer.getvalue()

st.sidebar.title('🛍️ ShopWise AI')
page=st.sidebar.radio('Navigation',['Dashboard','AI Shopping Assistant','Product Comparison','Budget Optimizer','Shopping Cart','Agent Activity','Decision Reports'])
st.sidebar.caption('Explainable AI Shopping Decision Agent')
st.title(page)
if page=='Dashboard':
    s=db.stats(); cols=st.columns(3)
    for col,(label,value) in zip(cols,[('Total searches',s['searches']),('Products evaluated',s['evaluated']),('Saved decisions',s['decisions'])]):col.metric(label,value)
    st.info('Statistics reflect persisted activity. No sample activity is counted until you run a search.')
    history=db.activities()[:10]
    if history: st.dataframe(pd.DataFrame(history),hide_index=True,use_container_width=True)
    else: st.write('No activity yet. Start with the AI Shopping Assistant.')
elif page=='AI Shopping Assistant':
    query=st.text_area('Describe what you want to buy','I need wireless headphones for online classes and travelling under 100')
    offline=st.toggle('Use clearly labelled offline sample catalogue',value=True)
    if st.button('Run shopping agent',type='primary'):
        try:
            try: api_key=st.secrets.get('GEMINI_API_KEY','')
            except Exception: api_key=''
            intent,intent_mode=understand_intent(query,api_key)
            if intent.get('currency') == 'INR':
                raise ValueError('The demo catalogue is priced in USD. Please enter a USD budget; currency conversion is not supported.')
            st.session_state.intent=intent
            st.session_state.explanation=''
            search_term=intent['categories'][0]
            items,mode=search_products(search_term,offline=offline)
            st.session_state.items=items; st.session_state.mode=mode
            sid=db.start(query,mode,len(items));st.session_state.session=sid
            db.log(sid,'Intent understanding',json.dumps({'intent':intent,'method':intent_mode}))
            db.log(sid,'Planning',f'Search category {search_term}, normalize products, score, flag risks and rank')
            db.log(sid,'Product search tool',f'{mode}: {len(items)} products returned')
            db.log(sid,'Data normalization',f'Validated {len(items)} catalogue products')
            ranked=sorted(items,key=lambda x:score(x,intent['budget'],[query])[0],reverse=True)
            st.session_state.ranked=ranked
            db.log(sid,'Evaluation',f'Evaluated {len(items)} products with deterministic scoring and risk checks')
            db.log(sid,'Decision',f'Top candidate: {ranked[0].title}' if ranked else 'No results')
        except Exception as e:
            st.error(f'Product search failed: {type(e).__name__}: {e}. Enable offline sample mode and retry.')
    intent=st.session_state.intent;items=st.session_state.ranked
    if intent:
        st.write('**Extracted intent:**',intent)
        st.caption('Catalogue source: '+st.session_state.mode+' | Demo prices are USD, not verified retailer offers. No automatic currency conversion.')
    if items:
        st.subheader('Ranked product results')
        st.caption('Agent execution: intent → plan → external search → normalization → scoring → risk analysis → recommendation. See Agent Activity for logged steps.')
        st.dataframe(pd.DataFrame(rows(items)),hide_index=True,use_container_width=True)
        st.caption('Score = 20% affordability + 20% rating + 15% availability + 25% keyword relevance + 5% completeness + 15% value. Over-budget items receive a score penalty. This is a heuristic, not a trained ML model.')
        st.bar_chart(pd.DataFrame({'Product':[x.title for x in items[:10]],'Score':[score(x,intent.get('budget'),[intent['query']])[0] for x in items[:10]]}).set_index('Product'))
        for x in items[:10]:
            with st.expander(f'{x.title} · {x.price:.2f} · {score(x,intent.get("budget"),[intent["query"]])[0]}/100'):
                st.write(x.description or 'Description unavailable');st.write('Risk flags:',risks(x) or ['No heuristic warnings']);st.json(score(x,intent.get('budget'),[intent['query']])[1]);st.caption('Source: '+x.source)
                if st.button('Add to simulated cart',key='add_'+x.id): db.add(x);db.log(st.session_state.session,'Cart action',f'Added {x.title}');st.success('Added to simulated cart')
        try: api_key=st.secrets.get('GEMINI_API_KEY','')
        except Exception: api_key=''
        if st.button('Generate recommendation explanation'):
            payload=rows(items)
            explanation,mode=explain(intent['query'],[{'title':r['Product'],'price':r['Price'],'score':r['Score'],'risks':r['Warnings']} for r in payload],api_key)
            st.session_state.explanation=explanation;db.log(st.session_state.session,'Explanation',mode)
        if st.session_state.get('explanation'): st.write(st.session_state.explanation)
        if st.button('Save current decision'):
            summary=f'Best match: {items[0].title} (score {score(items[0],intent.get("budget"),[intent["query"]])[0]})'
            db.save(st.session_state.session,summary,{'intent':intent,'source':st.session_state.mode,'products':rows(items),'explanation':st.session_state.get('explanation','')})
            db.log(st.session_state.session,'Saving decision',summary);st.success('Decision saved')
    elif intent: st.warning('No matching products returned. Try a broader category or the sample catalogue.')
elif page=='Product Comparison':
    items=st.session_state.items
    if len(items)<3: st.info('Search for products first. At least three results are needed.')
    else:
        chosen=st.multiselect('Choose products to compare',[x.id for x in items],default=[x.id for x in items[:3]],format_func=lambda id:next(x.title for x in items if x.id==id))
        if len(chosen)<3: st.warning('Select at least three products.')
        else:
            selected=[x for x in items if x.id in chosen];st.dataframe(pd.DataFrame(rows(selected)),hide_index=True,use_container_width=True)
            winner=max(selected,key=lambda x:score(x,st.session_state.intent.get('budget'),[st.session_state.intent.get('query','')])[0]);st.success(f'Highest heuristic match: {winner.title}. Review risks and actual specifications before buying.')
elif page=='Budget Optimizer':
    budget=st.number_input('Maximum budget (catalogue currency)',min_value=1.0,value=100.0)
    categories=st.text_input('Categories to purchase (comma-separated)','headphones, bags')
    offline=st.toggle('Use sample catalogue for optimizer',value=True)
    if st.button('Find best combination',type='primary'):
        groups=[];sources=[]
        try:
            requested=[x.strip() for x in categories.split(',') if x.strip()]
            if not requested or len(requested)>5: raise ValueError('Enter between one and five categories.')
            for cat in requested:
                found,src=search_products(cat,offline=offline);groups.append(found);sources.append(src)
            result=optimize(groups,budget)
            if result:
                st.success(f'Total: {result["total"]:.2f} | Remaining: {result["remaining"]:.2f}')
                st.dataframe(pd.DataFrame(rows(result['items'])),hide_index=True)
                st.caption('Selected the best combination among up to eight top-scored available candidates per category. Not guaranteed globally optimal. Prices in USD. Source: '+', '.join(set(sources)))
                for x in result['items']:
                    if st.button('Add '+x.title,key='opt_'+x.id):db.add(x);st.success('Added')
            else:st.warning('No complete available combination fits the budget. Try fewer categories or a higher budget.')
        except Exception as e:st.error(f'Optimization search failed: {e}. Try sample mode.')
elif page=='Shopping Cart':
    items=db.cart()
    if not items:st.info('Your simulated cart is empty.')
    else:
        for item in items:
            a,b,c=st.columns([5,2,2]);a.write(f'**{item["title"]}** · {item["price"]:.2f} each');n=b.number_input('Quantity',min_value=0,value=item['quantity'],key='q'+item['id']);
            if c.button('Update',key='upd'+item['id']):db.quantity(item['id'],n);st.rerun()
        st.metric('Simulated cart total',f'{sum(x["price"]*x["quantity"] for x in items):.2f}')
        st.caption('Demo only. No checkout or payment processing.')
elif page=='Agent Activity':
    activity=db.activities()
    if activity:st.dataframe(pd.DataFrame(activity),hide_index=True,use_container_width=True)
    else:st.info('No agent actions logged yet.')
elif page=='Decision Reports':
    saved=db.decisions()
    if not saved:st.info('No saved decisions yet.')
    for d in saved:
        with st.expander(f'#{d["id"]} · {d["summary"]} · {d["created_at"]}'):
            payload=json.loads(d['payload']);st.json(payload)
            lines=[d['summary'],f'User request: {payload["intent"]["query"]}',f'Catalogue source: {payload["source"]}']
            lines += [f'{p["Product"]} | price {p["Price"]} | score {p["Score"]} | warnings {p["Warnings"]}' for p in payload['products']]
            lines += ['Explanation: '+payload.get('explanation',''),'Scores are heuristic; product data may be sample/demo data.']
            st.download_button('Download PDF report',pdf_report('ShopWise AI Decision Report',lines),file_name=f'shopwise_decision_{d["id"]}.pdf',mime='application/pdf',key='dl'+str(d['id']))
